<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       thorstenschiller.com
 * @since      1.0.0
 *
 * @package    Clapper
 * @subpackage Clapper/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
